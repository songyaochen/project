function [x, P] = tu_qw_no_angular_rates(x, P, T, Rw)
%   calculates mean and covariance of predicted state
%   density using discretized model : q(k) = F*q(k-1) + G*v(k-1)
% Input:
%   x           [n x 1] Prior mean
%   P           [n x n] Prior covariance
%   T           the time since the last measurement
%   Rw          [m x m] process noise covariance matrix
%
% Output:
%   x           [n x 1] predict mean
%   P           [n x n] predict covariance
%    
%   discretized model : q(k) = F*q(k-1) + G*v(k-1)
G = (T/2) * Sq(x);
x = x;
% update mean and cov
P = P + G * Rw * G';
end

    
