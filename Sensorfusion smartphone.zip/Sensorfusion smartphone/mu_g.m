function [x,P] = mu_g(x,P,yacc,Ra,g0)

hx=Qq(x)'*g0;
[dQ0, dQ1, dQ2, dQ3] = dQqdq(x);

Hx=[dQ0'*g0, dQ1'*g0, dQ2'*g0, dQ3'*g0];
S=Hx*P*Hx'+Ra;
k=P*Hx'*inv(S);   
x=x+k*(yacc-hx);   
P=P-k*S*k';
end

