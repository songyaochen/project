
startup();
showIP();

% Collect data for initial estimation 
[xhat, meas] = filterTemplate();
%%
%file_name = ['data_' datestr(now,30) '.mat'];
% save(file_name,'xhat','meas');

%% Get data

gyro = meas.gyr(:,~any(isnan(meas.gyr),1));
gyro_x = gyro(1,:); gyro_y = gyro(2,:); gyro_z = gyro(3,:);

acc = meas.acc(:,~any(isnan(meas.acc),1));
acc_x = acc(1,:); acc_y = acc(2,:); acc_z = acc(3,:);

mag = meas.mag(:,~any(isnan(meas.mag),1));
mag_x = mag(1,:); mag_y = mag(2,:); mag_z = mag(3,:);



% Calculate mean and covariances

mu_gyro = mean(gyro,2);
cov_gyro = cov(gyro');

mu_acc = mean(acc,2);
cov_acc = vpa(cov(acc'));

mu_mag = mean(mag,2);
cov_mag = cov(mag');

% Plot gyro

t = meas.t(~any(isnan(meas.gyr),1));
figure()
plot(t, gyro_x, t, gyro_y, t, gyro_z); hold on
title('Gyro measurements')
legend('gyro_x', 'gyro_y', 'gyro_z')
axis([0 9 -0.04 0.08 ])
xlabel('Time [m/s]')
ylabel('Angular Velocity [rad/s]')

% Plot accelerometer
t = meas.t(~any(isnan(meas.acc),1));
figure()
plot(t, acc_x, t, acc_y, t, acc_z); hold on
title('Accelerometer measurements')
legend('acc_x', 'acc_y', 'acc_z')
axis([0 9 -2 12 ])
xlabel('Time [m/s]')
ylabel('Acceleration [m/s^2]')

% Plot magnetometer
t = meas.t(~any(isnan(meas.mag),1));
figure()
plot(t, mag_x, t, mag_y, t, mag_z); hold on
title('Magnetometer measurements')
legend('mag_x', 'mag_y', 'mag_z')
axis([0 9 -80 40 ])
xlabel('Time [m/s]')
ylabel('Magnetic Field [uT]')

% Plot histogram gyro

% error_gyro = gyro - mu_gyro;
figure()
Titel = {'Gyro_x', 'Gyro_y', 'Gyro_z'};
for i = 1:3
    subplot(1,3,i)
    histogram(gyro(i,:), 9, 'normalization', 'pdf'); hold on
    tmp = linspace(mu_gyro(i)-4*sqrt(cov_gyro(i,i)), mu_gyro(i)+4*sqrt(cov_gyro(i,i)));
    pdf_gyro = normpdf(tmp, mu_gyro(i), sqrt(cov_gyro(i,i)));
    plot(tmp, pdf_gyro,'LineWidth',2)
    title(Titel(i))
    xlabel('Time [m/s]')
end

% Plot histogram accelerometer
% close all
% error_acc = acc - mu_acc;
figure()
Titel = {'Accelerometer_x','Accelerometer_y','Accelerometer_z'};
for i = 1:3
    subplot(1,3,i)
    histogram(acc(i,:), 'normalization', 'pdf'); hold on
    tmp = linspace(mu_acc(i)-4*sqrt(cov_acc(i,i)), mu_acc(i)+4*sqrt(cov_acc(i,i)));
    pdf_acc = normpdf(tmp, mu_acc(i), sqrt(cov_acc(i,i)));
    plot(tmp, pdf_acc,'LineWidth',2)
    title(Titel(i))
    xlabel('Time [m/s]')

end

% Plot histogram magnetometer
% close all
% error_mag = mag - mu_mag;
figure()
Titel = {'Magnetometer_x','Magnetometer_y','Magnetometer_z'};

for i = 1:3
    subplot(1,3,i)
    histogram(mag(i,:), 'normalization', 'pdf'); hold on
    tmp = linspace(mu_mag(i)-4*sqrt(cov_mag(i,i)), mu_mag(i)+4*sqrt(cov_mag(i,i)));
    pdf_mag = normpdf(tmp, mu_mag(i), sqrt(cov_mag(i,i)));
    plot(tmp, pdf_mag,'LineWidth',2)
    title(Titel(i))
    xlabel('Time [m/s]')
end
%%
figure()
T_5 = xhat.t(2:end);
plot(T_5, xhat.x(1,:))
hold on
plot(T_5, xhat.x(2,:))
plot(T_5, xhat.x(3,:))
plot(T_5, xhat.x(4,:))
hold off
