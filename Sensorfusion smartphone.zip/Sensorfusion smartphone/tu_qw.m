function [x, P] = tu_qw(x, P, omega, T, Rw)
%   calculates mean and covariance of predicted state
%   density using discretized model : q(k) = F*q(k-1) + G*v(k-1)
% Input:
%   x           [n x 1] Prior mean
%   P           [n x n] Prior covariance
%   omega       [m x 1] Measurement
%   T           the time since the last measurement
%   Rw          [m x m] process noise covariance matrix
%
% Output:
%   x           [n x 1] predict mean
%   P           [n x n] predict covariance
%    
%   discretized model : q(k) = F*q(k-1) + G*v(k-1)


F = eye(4) + (T/2) * Somega(omega);
G = (T/2) * Sq(x);

% update mean and cov
x = F * x;
P = F * P * F' + G * Rw * G';

end

